﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PDFGenPOC.Models;
using Syncfusion.DocIO.DLS;
using Syncfusion.DocIO;
using Syncfusion.DocIORenderer;
using Syncfusion.Pdf;

namespace PDFGenPOC.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult WordToPDF(IFormFile sample)
        {
            if (sample != null)
            {
                string extension = Path.GetExtension(Request.Form.Files[0].FileName).ToLower();
                string output = Path.GetFileNameWithoutExtension(Request.Form.Files[0].FileName);
                Stream stream = new FileStream(Path.GetTempFileName(), FileMode.Create);
                Request.Form.Files[0].CopyToAsync(stream);
                WordDocument document = new WordDocument(stream, FormatType.Automatic);
                DocIORenderer render = new DocIORenderer();
                PdfDocument pdf = render.ConvertToPDF(document);
                MemoryStream memoryStream = new MemoryStream();
                pdf.Save(memoryStream);
                render.Dispose();
                pdf.Close();
                document.Close();
                memoryStream.Position = 0;
                return File(memoryStream, "application/pdf", output + ".pdf");
            }
            return View();
        }
        
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
